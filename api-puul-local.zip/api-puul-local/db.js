const fs = require('fs');  // Asegúrate de importar fs para manejar el sistema de archivos
const mysql = require('mysql2');

const pool = mysql.createPool({
  host: 'mysql-37d7c000-puul.i.aivencloud.com', // Usa tu host aquí
  user: 'avnadmin',                             // Usuario de la imagen
  password: 'AVNS_wStRj6fS9BNyfyV2uFF',         // Contraseña que aparece en la imagen
  database: 'puul',                             // Nombre de la base de datos
  port: 24058,                                  // Puerto de la imagen
  ssl: {
    ca: fs.readFileSync('/Users/pablovelazquezb/Desktop/ca.pem'),  // Ruta al certificado CA
    rejectUnauthorized: true,                  // SSL está requerido
  },
});

module.exports = pool.promise();
