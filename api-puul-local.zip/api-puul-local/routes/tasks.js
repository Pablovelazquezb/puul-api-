const express = require('express');
const router = express.Router();
const pool = require('../db');

// Obtener todas las tareas
router.get('/', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM tasks');
    res.json(rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error del servidor');
  }
});

// Crear una nueva tarea
router.post('/', async (req, res) => {
  const { title, description, estimated_hours, due_date, status, cost } = req.body;
  try {
    const [result] = await pool.query(
      'INSERT INTO tasks (title, description, estimated_hours, due_date, status, cost) VALUES (?, ?, ?, ?, ?, ?)',
      [title, description, estimated_hours, due_date, status, cost]
    );
    res.json({ id: result.insertId, title, description, estimated_hours, due_date, status, cost });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error del servidor');
  }
});

// Actualizar una tarea
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { title, description, estimated_hours, due_date, status, cost } = req.body;
  try {
    const [result] = await pool.query(
      'UPDATE tasks SET title = ?, description = ?, estimated_hours = ?, due_date = ?, status = ?, cost = ? WHERE id = ?',
      [title, description, estimated_hours, due_date, status, cost, id]
    );
    res.json(result);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error del servidor');
  }
});

// Eliminar una tarea
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM tasks WHERE id = ?', [id]);
    res.send('Tarea eliminada');
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error del servidor');
  }
});

module.exports = router;
