const express = require('express');
const router = express.Router();
const pool = require('../db');

// GET de todas las tareas
router.get('/', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM user_tasks');
      res.json(rows);
    } catch (err) {
      console.error(err.message);
      res.status(500).send('Error del servidor');
    }
  });



// Asignar una tarea a un usuario
router.post('/', async (req, res) => {
  const { user_id, task_id } = req.body;

  try {
    const [result] = await pool.query(
      'INSERT INTO user_tasks (user_id, task_id) VALUES (?, ?)',
      [user_id, task_id]
    );
    res.json({ message: 'Tarea asignada al usuario', assignmentId: result.insertId });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Error al asignar tarea', details: err.message });
  }
});

// Obtener todas las tareas asignadas a un usuario específico
router.get('/user/:user_id', async (req, res) => {
  const { user_id } = req.params;

  try {
    const [rows] = await pool.query(
      'SELECT tasks.* FROM tasks JOIN user_tasks ON tasks.id = user_tasks.task_id WHERE user_tasks.user_id = ?',
      [user_id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Error al obtener tareas', details: err.message });
  }
});

// Obtener todos los usuarios asignados a una tarea específica
router.get('/task/:task_id', async (req, res) => {
  const { task_id } = req.params;

  try {
    const [rows] = await pool.query(
      'SELECT users.* FROM users JOIN user_tasks ON users.id = user_tasks.user_id WHERE user_tasks.task_id = ?',
      [task_id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Error al obtener usuarios', details: err.message });
  }
});

module.exports = router;
