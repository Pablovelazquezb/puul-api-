const express = require('express');
const router = express.Router();
const pool = require('../db');

// Crear un registro en task_analytics cuando se crea un usuario
router.post('/:user_id', async (req, res) => {
  const { user_id } = req.params;

  try {
    const [result] = await pool.query(
      'INSERT INTO task_analytics (user_id, total_completed_tasks, total_cost, total_time_spent) VALUES (?, 0, 0.00, 0.00)',
      [user_id]
    );
    res.json({ message: 'Estadísticas inicializadas para el usuario', analyticsId: result.insertId });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Error al inicializar estadísticas', details: err.message });
  }
});

module.exports = router;
