const express = require('express');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/users');
const taskRoutes = require('./routes/tasks');
const userTaskRoutes = require('./routes/userTasks');  
const taskAnalyticsRoutes = require('./routes/taskAnalytics');


const app = express();
app.use(bodyParser.json());

// Rutas
app.use('/api/users', userRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/usertasks', userTaskRoutes);
app.use('/api/taskanalytics', taskAnalyticsRoutes);


const port = 3000;
app.listen(port, () => {
  console.log(`API running on http://localhost:${port}`);
});
